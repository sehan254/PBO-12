import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class KalkulatorLayout extends JFrame {
    private JTextField textField;

    public KalkulatorLayout() {
        setTitle("Kalkulator Layout");
        setSize(500, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel atas untuk text field
        textField = new JTextField();
        textField.setEditable(false);
        textField.setFont(new Font("Arial", Font.PLAIN, 32));
        add(textField, BorderLayout.NORTH);

        // Panel bawah untuk tombol-tombol
        JPanel panelTombol = new JPanel();
        panelTombol.setLayout(new GridLayout(3, 6, 5, 5)); // 3 baris, 6 kolom

        String[] tombol = {
                "1", "2", "3", "4", "5", "6",
                "7", "8", "9", "0", "+", "-",
                "*", "/", "=", "%", "Mod", "Exit"
        };

        for (int i = 0; i < tombol.length; i++) {
            String t = tombol[i];
            JButton btn = new JButton(t);
            btn.setFont(new Font("Arial", Font.BOLD, 14));
            panelTombol.add(btn);

            // Event handler keluar
            if (t.equals("Exit")) {
                btn.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        System.exit(0);
                    }
                });
            }

            // Tambahkan fungsi lain sesuai kebutuhan di sini...
        }

        add(panelTombol, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new KalkulatorLayout().setVisible(true);
            }
        });
    }
}
